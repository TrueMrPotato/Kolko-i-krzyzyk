﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kolko_i_krzyzyk
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Boolean x = true;
        Boolean click0 = false;
        Boolean click01 = false;
        Boolean click1 = false;
        Boolean click11 = false;
        Boolean click2 = false;
        Boolean click21 = false;
        Boolean click3 = false;
        Boolean click31 = false;
        Boolean click4 = false;
        Boolean click41 = false;
        Boolean click5 = false;
        Boolean click51 = false;
        Boolean click6 = false;
        Boolean click61 = false;
        Boolean click7 = false;
        Boolean click71 = false;
        Boolean click8 = false;
        Boolean click81 = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (x == true && click01 == false)
            {
                click0 = true;
                x = false;
                A1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click0 == false)
            {
                click01 = true;
                x = true;
                A1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (x == true && click11 == false)
            {
                click1 = true;
                x = false;
                A2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click1 == false)
            {
                click11 = true;
                x = true;
                A2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (x == true && click21 == false)
            {
                click2 = true;
                x = false;
                A3.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click2 == false)
            {
                click21 = true;
                x = true;
                A3.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (x == true && click31 == false)
            {
                click3 = true;
                x = false;
                B1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click3 == false)
            {
                click31 = true;
                x = true;
                B1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (x == true && click41 == false)
            {
                click4 = true;
                x = false;
                B2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click4 == false)
            {
                click41 = true;
                x = true;
                B2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (x == true && click51 == false)
            {
                click5 = true;
                x = false;
                B3.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click5 == false)
            {
                click51 = true;
                x = true;
                B3.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {

            if (x == true && click61 == false)
            {
                click6 = true;
                x = false;
                C1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if (x == false && click6 == false)
            {
                click61 = true;
                x = true;
                C1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {

            if (x == true && click71 == false)
            {
                click7 = true;
                x = false;
                C2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));

            }
            else if (x == false && click7 == false)
            {
                click71 = true;
                x = true;
                C2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            if (x == true && click81 == false)
            {
                click8 = true;
                x = false;
                C3.Source = new BitmapImage(new Uri("pack://application:,,,/Images/X.png"));
            }
            else if(x == false && click8 == false)
            {
                click81 = true;
                x = true;
                C3.Source = new BitmapImage(new Uri("pack://application:,,,/Images/O.png"));
            }
            Wygrana();
        }






        private void Wygrana()
        {


            // X X X 
            //
            //
            if(click0 == true && click3 == true && click6 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if(click01 == true && click31 == true && click61 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            //
            // X X X
            // 
            if (click1 == true && click4 == true && click7 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click11 == true && click41 == true && click71 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            //
            // 
            // X X X
            if (click2 == true && click5 == true && click8 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click21 == true && click51 == true && click81 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            // -----------------------------------------------------------------------


            // X
            // X
            // X
            if (click0 == true && click1 == true && click2 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click01 == true && click11 == true && click21 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            //   X
            //   X
            //   X
            if (click3 == true && click4 == true && click5 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click31 == true && click41 == true && click51 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            //     X
            //     X
            //     X
            if (click6 == true && click7 == true && click8 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click61 == true && click71 == true && click81 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            // -----------------------------------------------------------------------


            //     X
            //   X
            // X
            if (click2 == true && click4 == true && click6 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click21 == true && click41 == true && click61 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            // X
            //   X
            //     X
            if (click0 == true && click4 == true && click8 == true)
            {
                MessageBox.Show("Wygrywa X");
                Reset();
            }
            else if (click01 == true && click41 == true && click81 == true)
            {
                MessageBox.Show("Wygrywa O");
                Reset();
            }


            // REMIS


            if((click0 || click01 == true) && (click1 || click11 == true) && (click2 || click21 == true) && (click3 || click31 == true) && (click4 || click41 == true) && (click5 || click51 == true) && (click6 || click61 == true) && (click7 || click71 == true) && (click8 || click81 == true))
            {
                MessageBox.Show("Remis");
                Reset();
            }
        }

        private void Reset()
        {
            A1.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            A2.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            A3.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            B1.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            B2.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            B3.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            C1.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            C2.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            C3.Source = new BitmapImage(new Uri("pack://application:,,,/Blank.jpg"));
            x = true;
            click0 = false;
            click01 = false;
            click1 = false;
            click11 = false;
            click2 = false;
            click21 = false;
            click3 = false;
            click31 = false;
            click4 = false;
            click41 = false;
            click5 = false;
            click51 = false;
            click6 = false;
            click61 = false;
            click7 = false;
            click71 = false;
            click8 = false;
            click81 = false;
        }
    }
}
